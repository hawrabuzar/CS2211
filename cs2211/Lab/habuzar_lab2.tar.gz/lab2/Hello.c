#include <stdio.h>

int main()
{
	printf("hello! This is the output of my lab1:)\n");
	return 0;
}


/*
 *  Your assignments are to be submitted electronically through OWL course website. Online submissions may be checked for similarity.An assignment may contain two parts.
 *
1. Conceptual Questions: The TA’s will mark the pdf file 
submitted for this part of your assignment.
2. Programming Questions: The TA’s will check your assignment code on UNIX server (compute.gaul.csd.uwo.ca) in GAUL network. Youmust ensure  that everything works properly in your GAUL account (compute.gaul.csd.uwo.ca) before submitting your assignment.
*/
