#include <stdio.h>

int main(){
	printf("Hello CS2211 2025!\n");
	return 0;
}

